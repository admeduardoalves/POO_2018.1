# Anotações

##  que voce fez?

- fiz o controller e a classe nota.

## Com quem e como você fez?

- Eduardo Alves e com ajuda de video aulas.primeiro tivemos que criamos as classes seus objetos. Depois criamos seus to string. em seguida criamos a classe controller na qual tivemos mais dificuldade, pois não conseguiamos abstrair direito como ultilizar a questão do repositorio e os que conseguimos não sabiamos resolver por completo. assistimos as video aulas vizando revisar coisas q tinhamos esquecido e q poderia ser util para o desenvolvimento da classe controller. em seguida criamos a classe controller e suas condiuções para as interações com usuario.	 

## O que aprendeu e sabe fazer?

- a ultilizar melhor a classe repositorio.

## O que tem dificuldade ainda?

- ultilizar a classe repositorio.


## Quanto tempo levou pra fazer a atividade?

- 96 hrs

